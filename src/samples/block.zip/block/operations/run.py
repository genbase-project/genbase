#!/usr/bin/env python3
import os
import psycopg2
from typing import Dict

def get_connection():
    """Create database connection from environment variables"""
    return psycopg2.connect(
        host=os.getenv('POSTGRES_HOST'),
        port=os.getenv('POSTGRES_PORT'),
        user=os.getenv('POSTGRES_USER'),
        password=os.getenv('POSTGRES_PASSWORD'),
        database=os.getenv('POSTGRES_DB', 'postgres')
    )

def read_sql_file(path: str) -> str:
    """Read SQL file content"""
    with open(path, 'r') as f:
        return f.read()

def main():
    # Read the schema SQL
    schema_sql = read_sql_file('../../state/schema.sql')
    
    # Connect and execute
    with get_connection() as conn:
        with conn.cursor() as cur:
            # Execute schema changes
            cur.execute(schema_sql)
            
            # Verify the changes
            cur.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = 'public'
            """)
            tables = cur.fetchall()
            print("Tables created:", tables)

if __name__ == "__main__":
    main()